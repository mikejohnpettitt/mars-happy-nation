import styles from "@/app/ui/logo.module.scss";

export default function Logo() {
  return (
    <>
      <div className={styles.mars}></div>
      <div>Mars Happy Nation</div>
    </>
  )
}
